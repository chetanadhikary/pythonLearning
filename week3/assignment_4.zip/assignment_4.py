class Student:
    '''

    >>>student1 = Student('Harry','Griffyndor','Quidditch','Defense against the dark arts')

    >>>print(student1)

    The student name is : Harry
    The student branch is: Griffyndor
    The student hobbies are:('Quidditch', 'Defense against the dark arts')

    >>>student2 = Student('Harmoine','Griffyndor','Charms','Arithmancy','Portions')

    The student name is : Harmoine
    The student branch is: Griffyndor
    The student hobbies are:('Charms', 'Arithmancy', 'Portions')
    >>>print(student2)

    >>>student2>student1
    True
    '''
    ## Begin your code here
    
    
    
    ##End your code here